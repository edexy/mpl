# Mock Premier League Fixtures API
npm run test